package com.hsbc.sport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class HsbceurekaserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(HsbceurekaserverApplication.class, args);
	}

}
