package com.hsbc.sports.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class WinnerConfiguration {
	//rest template is used to invoke rest service
	// for interservice communication
	@Bean
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}

}
