/*package com.hsbc.sports.controllers;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.client.RestTemplate;

import com.hsbc.sports.models.Winner;

//import com.hsbc.sports.models.Winner;

@Controller
public class WinnerMVCController {
	@Autowired
	private RestTemplate restTemplate;
	@Value("${serviceUrl}")
	private String serviceUrl;

	// return index.html on loading the page
	@GetMapping("/")
	public String home(Model model) {
		// exchange(which m
		ResponseEntity<Winner[]> responseEntity = restTemplate.exchange(serviceUrl, HttpMethod.GET, null,
				Winner[].class);

		Winner[] winners = responseEntity.getBody();

		List<Winner> winnerList = Arrays.asList(winners);

		for (Winner winner : winnerList) {
			System.out.println("winner list" + winner.getWinnerName());
		}
		model.addAttribute("winnerList", winnerList);

		return "index";
	}
	
	@GetMapping("/loadWinner")
	public String loadWinnerForm(Model model)
	{
		model.addAttribute("winnner", new Winner());
		return  "addWinner";
	}

	@PostMapping("/winners")
	public String addWinner(@ModelAttribute("winner") Winner winner) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Winner> request = new HttpEntity<>(winner, headers);
		// sending data to rest API winners.
		ResponseEntity<Winner> serviceResponse = restTemplate.postForEntity(serviceUrl, request,
				Winner.class);
		return "redirect:/";
	}

}*/

package com.hsbc.sports.controllers;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.hsbc.sports.models.Winner;

//import com.hsbc.sports.models.Winner;


//this has no connectivity  with backend
@Controller
public class WinnerMVCController {
	@Autowired
	private RestTemplate restTemplate;
	@Value("${serviceUrl}")
	private String serviceUrl;

	// return index.html on loading the page
	@GetMapping("/")
	public String home(Model model) {
		// exchange(which m
		ResponseEntity<Winner[]> responseEntity = restTemplate.exchange(serviceUrl, HttpMethod.GET, null,
				Winner[].class);

		Winner[] winners = responseEntity.getBody();

		List<Winner> winnerList = Arrays.asList(winners);

//		for (Winner winner : winnerList) {
//			System.out.println("winner list" + winner.getWinnerName());
//		}
		model.addAttribute("winnerList", winnerList);

		return "index";
	}

	@GetMapping("/loadWinnerForm")
	public String loadwinnerForm(Model model) {

		model.addAttribute("winner", new Winner());
		return "addWinner";
	}

	@GetMapping("/loadWinnerSearchForm")
	public String loadwinnerSearchForm() {
		return "searchwinner";
	}

	// will receive here after submission
	@PostMapping("/winners")
	public String addWinner(@ModelAttribute("winner") Winner winner) {

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Winner> request = new HttpEntity<>(winner, headers);
		ResponseEntity<Winner> authResponse = restTemplate.postForEntity(serviceUrl, request, Winner.class);
		return "redirect:/";
	}
	
	

	@PostMapping("/searchWinners")
	public String seacrhWinner(@RequestParam("winnerName") String winnerName, Model model) {

		ResponseEntity<Winner[]> responseEntity = restTemplate.exchange(serviceUrl+ "/" + winnerName, HttpMethod.GET, null,
				Winner[].class);

		Winner[] winners = responseEntity.getBody();

		List<Winner> winnerList = Arrays.asList(winners);

//		for (Winner winner : winnerList) {
//			System.out.println("winner list" + winner.getWinnerName());
//		}
		model.addAttribute("winnerList", winnerList);
		//return is basically a html page
		return "showWinnerDataByName";
	}

}