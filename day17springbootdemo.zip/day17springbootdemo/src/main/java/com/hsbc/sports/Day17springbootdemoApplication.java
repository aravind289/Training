package com.hsbc.sports;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day17springbootdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day17springbootdemoApplication.class, args);
	}

}
