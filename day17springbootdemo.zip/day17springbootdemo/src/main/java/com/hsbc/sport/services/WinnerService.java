package com.hsbc.sport.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hsbc.sport.models.Winner;
import com.hsbc.sport.repositories.WinnerRepository;

@Service
public class WinnerService {
	@Autowired
	//connect ot winner repo
	private WinnerRepository winnerRepo;
	
	//insert query
	public Winner addWinner(Winner winner) {
		return winnerRepo.save(winner);
	}
	
	
	//select al query
	public List<Winner> getallWinners(){
		return winnerRepo.findAll();
	}
	
	
	//select by player name
	//non primary key 
	//this is custom method that is created in  winnerrepository
	public List<Winner> getPlayerByName(String playerName){
		return winnerRepo.findByPlayerName(playerName);
	}
	
	public boolean deleteById() {
		System.out.println(winnerRepo);
		return true;
	}
	
	
}
