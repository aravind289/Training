package com.hsbc.sport.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.hsbc.sport.models.Winner;


public interface WinnerRepository extends JpaRepository<Winner,Integer>{
	//jpaql
	
	//basic goal of this layer is reduce the implementation of dao layer 
	//select _objectreturned that is refernced from classname refernce variable where ref.modelvalue=:parameter
	@Query("select winner from Winner winner where winner.winnerName=:playerName")
	public List<Winner> findByPlayerName(@Param("playerName")String playerName);
}
